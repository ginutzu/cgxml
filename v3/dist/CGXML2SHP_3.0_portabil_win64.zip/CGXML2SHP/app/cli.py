# -*- coding: utf-8 -*-
"""Pornește CGXML2SHP în linie de comandă (apelat de cgxml2shp-cli.cmd)."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from cgxml2shp.cli import main  # noqa: E402

sys.exit(main())
