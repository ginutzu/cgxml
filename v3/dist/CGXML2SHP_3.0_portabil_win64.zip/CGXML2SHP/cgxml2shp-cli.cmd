@echo off
setlocal
"%~dp0runtime\python.exe" -I "%~dp0app\cli.py" %*
exit /b %ERRORLEVEL%
