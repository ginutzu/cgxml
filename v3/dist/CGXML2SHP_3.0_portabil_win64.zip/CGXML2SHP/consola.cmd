@echo off
cd /d "%~dp0"
title CGXML2SHP - linie de comanda
call cgxml2shp-cli.cmd --help
echo.
echo Exemplu: cgxml2shp-cli.cmd "D:\date\arhiva.zip" --constructii
cmd /k
